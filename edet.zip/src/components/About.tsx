import { motion } from 'motion/react';
import { Button } from './ui/button';
import { PlayCircle, Briefcase } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-24 bg-white px-4">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-8"
        >
          <h2 className="text-stone-900">Meet Edet Uboho</h2>
          
          <div className="space-y-6 text-stone-600 max-w-3xl mx-auto">
            <p>
              I'm a digital marketer, brand strategist, and visual storyteller with a passion for helping businesses 
              craft compelling narratives that resonate with their audience. Through data-driven strategies and creative 
              execution, I transform brands into memorable experiences that drive real results.
            </p>
            
            <p>
              With years of experience in social media growth, brand identity development, and digital campaign management, 
              I've helped numerous brands amplify their voice, expand their reach, and build lasting connections with their 
              customers. Let's work together to tell your brand's story in a way that captivates and converts.
            </p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-wrap gap-4 justify-center pt-4"
          >
            <Button 
              variant="outline" 
              className="border-stone-900 text-stone-900 hover:bg-stone-900 hover:text-white px-6 py-6 rounded-full transition-all duration-300"
            >
              <Briefcase className="mr-2 h-5 w-5" />
              View Portfolio
            </Button>
            
            <Button 
              className="bg-stone-900 hover:bg-stone-800 text-white px-6 py-6 rounded-full transition-all duration-300"
            >
              <PlayCircle className="mr-2 h-5 w-5" />
              Watch Introduction Video
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
