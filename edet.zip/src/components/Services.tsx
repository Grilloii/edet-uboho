import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { TrendingUp, Target, Zap } from 'lucide-react';

const services = [
  {
    icon: TrendingUp,
    title: 'Social Media Strategy & Growth',
    description: 'Build a loyal audience with data-driven social media strategies that increase engagement, expand reach, and drive meaningful conversations around your brand.',
  },
  {
    icon: Target,
    title: 'Brand Identity & Visibility',
    description: 'Craft a distinctive brand identity that stands out in your market. From visual storytelling to messaging frameworks, we create brands that people remember.',
  },
  {
    icon: Zap,
    title: 'Digital Campaigns & Marketing Systems',
    description: 'Launch high-converting digital campaigns backed by automation, analytics, and strategic precision. Turn your marketing into a scalable growth engine.',
  },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-stone-50 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-stone-900 mb-4">What I Do</h2>
          <p className="text-stone-600 max-w-2xl mx-auto">
            Transforming brands through strategic thinking, creative storytelling, and measurable results.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="h-full border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 bg-white group cursor-pointer">
                <CardHeader className="space-y-4">
                  <div className="w-16 h-16 bg-stone-100 rounded-2xl flex items-center justify-center group-hover:bg-stone-900 transition-colors duration-300">
                    <service.icon className="h-8 w-8 text-stone-900 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <CardTitle className="text-stone-900">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-stone-600 leading-relaxed">
                    {service.description}
                  </CardDescription>
                  <p className="mt-6 text-stone-900 group-hover:underline transition-all duration-300">
                    Learn More →
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
