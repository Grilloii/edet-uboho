import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { PlayCircle } from 'lucide-react';

const caseStudies = [
  {
    image: 'https://images.unsplash.com/photo-1542744094-f77e9f7a10b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbWFya2V0aW5nJTIwd29ya3NwYWNlfGVufDF8fHx8MTc2MTA3NjcxN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    title: 'Mowe Golf Town',
    description: 'How We Helped Mowe Golf Town Drive 10x Brand Reach',
    metric: '10x Brand Reach',
  },
  {
    image: 'https://images.unsplash.com/photo-1758631279366-8e8aeaf94082?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMHN0cmF0ZWd5JTIwY29uY2VwdHxlbnwxfHx8fDE3NjEwNzgyNzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    title: 'E-Commerce Growth',
    description: 'Scaling an E-Commerce Brand to $500K in Revenue',
    metric: '$500K Revenue',
  },
  {
    image: 'https://images.unsplash.com/photo-1622782914767-404fb9ab3f57?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NpYWwlMjBtZWRpYSUyMGdyb3d0aHxlbnwxfHx8fDE3NjEwNzgyNzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    title: 'Social Media Campaign',
    description: 'Building a Community of 50K Engaged Followers',
    metric: '50K Followers',
  },
];

export function CaseStudies() {
  return (
    <section id="case-studies" className="py-24 bg-white px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-stone-900 mb-4">Case Studies</h2>
          <p className="text-stone-600 max-w-2xl mx-auto">
            Real results for real brands. See how we've transformed businesses through strategic digital marketing.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {caseStudies.map((study, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300">
                <ImageWithFallback
                  src={study.image}
                  alt={study.title}
                  className="w-full h-80 object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-stone-900/50 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300" />
                
                {/* Content */}
                <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
                  <div className="flex items-center gap-2 mb-3">
                    <PlayCircle className="h-6 w-6" />
                    <span className="text-sm tracking-wider uppercase">{study.metric}</span>
                  </div>
                  <h3 className="mb-2">{study.title}</h3>
                  <p className="text-stone-200 text-sm">{study.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
