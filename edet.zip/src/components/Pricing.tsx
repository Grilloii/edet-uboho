import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Check } from 'lucide-react';

const pricingPlans = [
  {
    name: 'Basic Social',
    description: 'Perfect for startups',
    monthlyPrice: '$500',
    features: [
      '3 posts per week',
      'Content calendar planning',
      'Basic analytics & reporting',
      'Community management',
      '2 social platforms',
    ],
    multiMonthDiscount: '10% off for 3+ months',
  },
  {
    name: 'Premium Social',
    description: 'For growing brands',
    monthlyPrice: '$1,200',
    features: [
      '5 posts per week',
      'Advanced content strategy',
      'Influencer collaboration',
      'Video content creation',
      'All major platforms',
      'Monthly strategy calls',
    ],
    multiMonthDiscount: '15% off for 6+ months',
    popular: true,
  },
  {
    name: 'Basic Digital Marketing',
    description: 'Comprehensive campaigns',
    monthlyPrice: '$2,000',
    features: [
      'Full social media management',
      'Email marketing campaigns',
      'SEO optimization',
      'Ad campaign management',
      'Landing page design',
      'Bi-weekly reports',
    ],
    multiMonthDiscount: '15% off for 6+ months',
  },
  {
    name: 'Premium Digital Marketing',
    description: 'Complete brand solution',
    monthlyPrice: '$4,000',
    features: [
      'Everything in Basic Digital',
      'Brand strategy consultation',
      'Video production & editing',
      'Advanced automation',
      'Dedicated account manager',
      'Weekly strategy sessions',
      'Custom integrations',
    ],
    multiMonthDiscount: '20% off for 12+ months',
  },
];

export function Pricing() {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="pricing" className="py-24 bg-stone-50 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-stone-900 mb-4">Choose a Plan that Fits Your Growth</h2>
          <p className="text-stone-600 max-w-2xl mx-auto">
            Flexible pricing options designed to scale with your business. All plans include ongoing support and optimization.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pricingPlans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="h-full"
            >
              <Card className={`h-full flex flex-col relative ${plan.popular ? 'border-2 border-stone-900 shadow-2xl' : 'border-0 shadow-lg'} bg-white`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <span className="bg-stone-900 text-white px-4 py-1 rounded-full text-sm">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <CardHeader>
                  <CardTitle className="text-stone-900">{plan.name}</CardTitle>
                  <CardDescription className="text-stone-600">{plan.description}</CardDescription>
                  <div className="pt-4">
                    <span className="text-stone-900">{plan.monthlyPrice}</span>
                    <span className="text-stone-600 text-sm">/month</span>
                  </div>
                  <p className="text-xs text-stone-500 italic">{plan.multiMonthDiscount}</p>
                </CardHeader>
                
                <CardContent className="flex-grow flex flex-col justify-between">
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="h-5 w-5 text-stone-900 flex-shrink-0 mt-0.5" />
                        <span className="text-stone-700 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    onClick={scrollToContact}
                    className={`w-full rounded-full ${plan.popular ? 'bg-stone-900 hover:bg-stone-800 text-white' : 'bg-white border-2 border-stone-900 text-stone-900 hover:bg-stone-900 hover:text-white'} transition-all duration-300`}
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
