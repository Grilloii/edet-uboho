import { motion } from 'motion/react';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Send } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    package: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock form submission
    toast.success('Message sent successfully! I\'ll get back to you soon.');
    setFormData({ name: '', email: '', phone: '', package: '', message: '' });
  };

  return (
    <section id="contact" className="py-24 bg-white px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <Card className="border-0 shadow-2xl bg-gradient-to-br from-white to-stone-50">
            <CardHeader className="text-center">
              <CardTitle className="text-stone-900">Let's Build Something Great Together</CardTitle>
              <CardDescription className="text-stone-600">
                Ready to take your brand to the next level? Fill out the form below and let's start the conversation.
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-stone-900">Name</Label>
                    <Input
                      id="name"
                      placeholder="Your full name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                      className="border-stone-300 focus:border-stone-900"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-stone-900">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                      className="border-stone-300 focus:border-stone-900"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-stone-900">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+1 (555) 000-0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="border-stone-300 focus:border-stone-900"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="package" className="text-stone-900">Select a Package</Label>
                    <Select value={formData.package} onValueChange={(value) => setFormData({ ...formData, package: value })}>
                      <SelectTrigger className="border-stone-300 focus:border-stone-900">
                        <SelectValue placeholder="Choose a package" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic-social">Basic Social</SelectItem>
                        <SelectItem value="premium-social">Premium Social</SelectItem>
                        <SelectItem value="basic-digital">Basic Digital Marketing</SelectItem>
                        <SelectItem value="premium-digital">Premium Digital Marketing</SelectItem>
                        <SelectItem value="custom">Custom Solution</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message" className="text-stone-900">Message</Label>
                  <Textarea
                    id="message"
                    placeholder="Tell me about your project and goals..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    required
                    className="border-stone-300 focus:border-stone-900 min-h-32"
                  />
                </div>

                <Button 
                  type="submit"
                  className="w-full bg-stone-900 hover:bg-stone-800 text-white py-6 rounded-full transition-all duration-300"
                >
                  <Send className="mr-2 h-5 w-5" />
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
