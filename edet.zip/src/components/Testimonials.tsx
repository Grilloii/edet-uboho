import { motion } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from './ui/carousel';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah Johnson',
    brand: 'TechStart Inc.',
    testimonial: 'Working with Edet transformed our brand visibility. His strategic approach to social media helped us grow our audience by 300% in just 6 months.',
    initials: 'SJ',
  },
  {
    name: 'Michael Chen',
    brand: 'GreenLife Organics',
    testimonial: 'Edet\'s storytelling ability is unmatched. He took our brand message and turned it into a compelling narrative that resonates with our customers every single day.',
    initials: 'MC',
  },
  {
    name: 'Priya Sharma',
    brand: 'Digital Dynamics',
    testimonial: 'The ROI we\'ve seen from Edet\'s digital campaigns is outstanding. He combines creativity with data-driven insights to deliver results that exceed expectations.',
    initials: 'PS',
  },
  {
    name: 'David Williams',
    brand: 'Mowe Golf Town',
    testimonial: 'Edet helped us reach audiences we never thought possible. His expertise in brand strategy gave us the clarity and direction we needed to scale our business.',
    initials: 'DW',
  },
  {
    name: 'Lisa Martinez',
    brand: 'Creative Studios',
    testimonial: 'Professional, strategic, and incredibly talented. Edet brought our vision to life and helped us build a brand identity that truly stands out in the market.',
    initials: 'LM',
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-stone-900 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-white mb-4">What Clients Say</h2>
          <p className="text-stone-300 max-w-2xl mx-auto">
            Don't just take my word for it. Here's what brands have to say about our collaboration.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-5xl mx-auto"
        >
          <Carousel
            opts={{
              align: 'start',
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent>
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                  <Card className="h-full bg-white border-0 shadow-xl">
                    <CardContent className="p-6 flex flex-col h-full">
                      <Quote className="h-8 w-8 text-stone-300 mb-4" />
                      
                      <p className="text-stone-700 mb-6 flex-grow italic">
                        "{testimonial.testimonial}"
                      </p>
                      
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-stone-900 flex items-center justify-center text-white">
                          {testimonial.initials}
                        </div>
                        <div>
                          <p className="text-stone-900">{testimonial.name}</p>
                          <p className="text-stone-500 text-sm">{testimonial.brand}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="text-white border-white hover:bg-white hover:text-stone-900" />
            <CarouselNext className="text-white border-white hover:bg-white hover:text-stone-900" />
          </Carousel>
        </motion.div>
      </div>
    </section>
  );
}
